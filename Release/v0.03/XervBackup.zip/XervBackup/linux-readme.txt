Updated instructions for using XervBackup on linux can be found here:

http://code.google.com/p/XervBackup/wiki/LinuxHowto

Thanks for using XervBackup!